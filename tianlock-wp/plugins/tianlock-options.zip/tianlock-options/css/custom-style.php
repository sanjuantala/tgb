<?php /**
 * Generate the CSS for the current custom color scheme.
 */
function tianlock_wp_custom_colors_css() {

// Main Color (red)
$tianlock_wp_main_color1 = get_theme_mod('tianlock_wp_main_color1');
if (!empty($tianlock_wp_main_color1)) {
    // background color
    echo esc_html('#searchform2 .buttonicon, .my-paginated-posts span, #tags-wrap, #back-top span, .menu--adsila .menu__item:nth-child(odd) .menu__item-name::before, .menu--adsila .menu__item:nth-child(odd) .menu__item-label::before, .wp-pagenavi a:hover, .wp-pagenavi span.current, .single-category a, .entry-btn, #commentform #submit, input.ap-form-submit-button, .social-section, footer .widget-title-f, #back-top span, ul.modern-list li h2 .heading, ul.modern-list li h2, .text-300 .pink, a.comment-reply-link, .woocommerce span.onsale, a.add_to_cart_button:hover, .footer-woocommerce h3.title span, .entry a.btn_pink { background-color: '. $tianlock_wp_main_color1 .' !important;} ');
    // color
    echo esc_html('h3.index-title i, .widget-title h3 i, .wrap-footer p a, a:hover, .top-social li a:hover, ul.top-social li.search, #tianlock-404 h2, .menu--adsila .menu__item:nth-child(odd), .menu--adsila .menu__item:nth-child(odd):focus, .author-meta strong i, div.author-info i.fa-link, footer .wrap-middle .company-info a, footer .copyright a, footer .copyright_right a, .ant-responsive-menu li i, .menu--adsila .menu__item:nth-child(odd), .menu--adsila .menu__item:nth-child(odd):focus, .menu__item a, .text-300 h3, .prev-articles h2 a   { color: '. $tianlock_wp_main_color1 .' !important;} ');    
    // border
    echo esc_html('.featured-articles .title-box div.author-name a, footer .wrap-middle .company-info a { border-bottom: 1px solid '. $tianlock_wp_main_color1 .' !important;} ');
    // border
    echo esc_html('.entry p a, input.ap-form-submit-button, div.titleContainer, ul.featured-slider .content, #commentform #submit, ul.products li:hover img { border-color: '. $tianlock_wp_main_color1 .' !important;} ');
    // border
    echo esc_html('ul.modern-list li.sticky div.modern-list-content, ul.modern-list li.sticky div.modern-list-content-full { border-top: dashed 5px '. $tianlock_wp_main_color1 .' !important;} ');
    // border
    echo esc_html('.widget-title:after, h2.widgettitle:after, span.apsl-login-new-text:after { background: none repeat scroll 0% 0% '. $tianlock_wp_main_color1 .' !important;} ');
}
// Main Color (yellow)
$tianlock_wp_main_color2 = get_theme_mod('tianlock_wp_main_color2');
if (!empty($tianlock_wp_main_color2)) {
    // background color
    echo esc_html('div.random-slider-wrap { background-color: '. $tianlock_wp_main_color2 .' !important;} ');    
}
// Entry Link Color
$tianlock_wp_entry_linkcolor = get_theme_mod('tianlock_wp_entry_linkcolor');
if (!empty($tianlock_wp_entry_linkcolor)) {
    // BG Color
    echo esc_html('.entry p a { color: '. $tianlock_wp_entry_linkcolor .' !important;} ');
}
// Body Bg Color
$tianlock_wp_body_bg = get_theme_mod('tianlock_wp_body_bg');
if (!empty($tianlock_wp_body_bg)) {
    // BG Color
    echo esc_html('html body { background-color: '. $tianlock_wp_body_bg .' !important;} ');
}
// Module Bg Color
$tianlock_wp_module_leftbg = get_theme_mod('tianlock_wp_module_leftbg');
$tianlock_wp_module_rightbg = get_theme_mod('tianlock_wp_module_rightbg');
if (!empty($tianlock_wp_module_leftbg) || ($tianlock_wp_module_rightbg) ) {
    // BG Color
    echo esc_html('.module-section { background: linear-gradient(90deg, '. $tianlock_wp_module_leftbg .' 50%, '. $tianlock_wp_module_rightbg .' 50%);} ');
}
} ?>