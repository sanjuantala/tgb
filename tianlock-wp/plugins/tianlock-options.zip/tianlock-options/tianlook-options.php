<?php
/*
Plugin Name: TianLock Options
Plugin URL: https://anthemes.com
Description: Theme Functionality: Custom Style, Theme core, Post Views etc.
Version: 1.2
Author: An-Themes
Author URI: http://themeforest.net/user/An-Themes/portfolio
*/


// ------------------------------------------------ 
// ---- Display custom color CSS ------------------
// ------------------------------------------------
$theme = wp_get_theme(); // gets the current theme
if ( 'TianLock WP' == $theme->name || 'TianLock WP' == $theme->parent_theme ) {
    function tianlock_wp_colors_css_wrap() {
            require_once( dirname(__FILE__) . '/css/custom-style.php' );
        ?>
        <style type="text/css"><?php echo tianlock_wp_custom_colors_css(); ?></style>
        <?php }
    add_action( 'wp_head', 'tianlock_wp_colors_css_wrap' );
}


// ------------------------------------------------ 
// ---- Social share Single  ----------------------
// ------------------------------------------------ 
function tianlock_wp_social_share_single() { ?>
    <ul class="single-share">
        <li><?php $tianlock_wp_facebooklink = 'https://www.facebook.com/sharer/sharer.php?u='; ?><a class="fbbutton" target="_blank" href="<?php echo esc_url($tianlock_wp_facebooklink); ?><?php the_permalink(); ?>" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=400,width=700');return false;"><i class="fab fa-facebook-f" aria-hidden="true"></i> <span><?php esc_html_e( 'Share on Facebook', 'tianlock-wp' ); ?></span></a></li>
        <li><?php $tianlock_wp_twitterlink = 'https://twitter.com/intent/tweet?text=Check%20out%20this%20article:%20'; ?><a class="twbutton" target="_blank" href="<?php echo esc_url($tianlock_wp_twitterlink); ?><?php the_title(); ?>%20-%20<?php the_permalink(); ?>" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=400,width=700');return false;"><i class="fab fa-twitter"></i></a></li>
        <li><?php $tianlock_wp_articleimage = wp_get_attachment_url( get_post_thumbnail_id()); ?><?php $tianlock_wp_pinlink = 'https://pinterest.com/pin/create/button/?url='; ?><a class="pinbutton" target="_blank" href="<?php echo esc_url($tianlock_wp_pinlink); ?><?php the_permalink(); ?>&amp;media=<?php echo esc_html($tianlock_wp_articleimage); ?>&amp;description=<?php the_title(); ?>" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=400,width=700');return false;"><i class="fab fa-pinterest-p"></i></a></li>
    </ul><!-- end .single-share -->
<?php }


// ------------------------------------------------
// ---- Add  rel attributes to embedded images ----
// ------------------------------------------------ 
function insert_rel_tianlock_wp($content) {
    $pattern = '/<a(.*?)href="(.*?).(bmp|gif|jpeg|jpg|png)"(.*?)>/i';
    $replacement = '<a$1href="$2.$3" class=\'wp-img-bg-off\' rel=\'mygallery\'$4>';
    $content = preg_replace( $pattern, $replacement, $content );
    return $content;
}
add_filter( 'the_content', 'insert_rel_tianlock_wp' );


// ------------------------------------------------ 
// --- Pagination class/style for entry articles --
// ------------------------------------------------ 
function custom_nextpage_links_tianlock_wp($defaults) {
$args = array(
'before' => '<div class="my-paginated-posts"><p>' . '<span>',
'after' => '</span></p></div>',
);
$r = wp_parse_args($args, $defaults);
return $r;
}
add_filter('wp_link_pages_args','custom_nextpage_links_tianlock_wp');


// ------------------------------------------------ 
// ------------ Nr of Topics for Tags -------------
// ------------------------------------------------  
function set_wp_generate_tag_cloud_tianlock_wp($content, $tags, $args)
    { 
      $count=0;
      $output=preg_replace_callback('(</a\s*>)', 
      function($match) use ($tags, &$count) {
          return "<span class=\"tagcount\">".$tags[$count++]->count."</span></a>";  
      }
      , $content);
      
      return $output;
    }
add_filter('wp_generate_tag_cloud','set_wp_generate_tag_cloud_tianlock_wp', 10, 3);  


// ------------------------------------------------ 
// --------------- Posts Time Ago -----------------
// ------------------------------------------------  
function time_ago_tianlock_wp( $type = 'post' ) {
    $d = 'comment' == $type ? 'get_comment_time' : 'get_post_time';
    return human_time_diff($d('U'), current_time('timestamp')) . " ";
}


// ------------------------------------------------ 
// --- Restrict Content Pro - lock design style 1 -
// ------------------------------------------------ 
function tianlock_wp_rcp_lock() {
  if( function_exists( 'rcp_is_active' ) ) {
    if( rcp_user_can_access( get_current_user_id(), get_the_ID() ) ) {
        // user can access 
    } else {
        echo '<i class="fas fa-lock"></i>';
    }
  } // check if function exists
}


// ------------------------------------------------ 
// --- Restrict Content Pro - lock design style 2 -
// ------------------------------------------------ 
function tianlock_wp_rcp_lock2() {
  if( function_exists( 'rcp_is_active' ) ) {
    if( rcp_user_can_access( get_current_user_id(), get_the_ID() ) ) {
        // user can access 
    } else {
        echo '<div class="lockicon"><i class="fas fa-lock"></i></div>';
    }
  } // check if function exists
}


// ------------------------------------------------ 
// ------------ Number of post views --------------
// ------------------------------------------------
 // function to display number of posts.
function getPostViews_tianlock_wp($postID){
    $count_key = 'post_views_count_tianlock_wp';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return '0';
    }
    return $count;
}

// function to count views.
function setPostViews_tianlock_wp($postID) {
    $count_key = 'post_views_count_tianlock_wp';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}


// ------------------------------------------------ 
// ------------ Meta Box --------------------------
// ------------------------------------------------
$prefix = 'tianlock_wp_';
global $meta_boxes;
$meta_boxes = array();

// 1st meta box
$meta_boxes[] = array(
    'id' => 'standard',
    'title' => esc_html__( 'Article Page Options', 'tianlock-wp' ),
    'context' => 'normal',
    'priority' => 'high',
    'autosave' => true,

    'fields' => array(
    // Hide Featured Image
        // CheckBox
        array(
            'name' => esc_html__( 'Featured Image', 'tianlock-wp' ),
            'id'   => "{$prefix}hideimg",
            'desc'  => esc_html__( 'Hide Featured Image on single page for this article', 'tianlock-wp' ),
            'type' => 'checkbox',
        ),


    ),

);


/**
 * Register meta boxes
 *
 * @return void
 */
function tianlock_wp_register_meta_boxes()
{
    // Make sure there's no errors when the plugin is deactivated or during upgrade
    if ( !class_exists( 'RW_Meta_Box' ) )
        return;

    global $meta_boxes;
    foreach ( $meta_boxes as $meta_box )
    {
        new RW_Meta_Box( $meta_box );
    }
}
// Hook to 'admin_init' to make sure the meta box class is loaded before
// (in case using the meta box class in another plugin)
// This is also helpful for some conditionals like checking page template, categories, etc.
add_action( 'admin_init', 'tianlock_wp_register_meta_boxes' );


?>